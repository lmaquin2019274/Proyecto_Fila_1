package controller;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Integer.parseInt;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Artistas;
import model.Favoritos;
import model.HistorialReproduccion;
import model.MixeshasCanciones;
import model.PlaylisthasCanciones;
import model.Usuarios;
import modelDAO.ArtistasDAO;
import modelDAO.FavoritosDAO;
import modelDAO.HistorialReproduccionDAO;
import modelDAO.MixeshasCancionesDAO;
import modelDAO.PlaylisthasCancionesDAO;
import modelDAO.UsuariosDAO;

@WebServlet(name = "Controlador", urlPatterns = {"/Controlador"})
public class Controlador extends HttpServlet {
    
    String favoritos = "view/favoritos.jsp";
    String addFavoritos = "view/addFavoritos.jsp";
    Favoritos nuevoFav = new Favoritos();
    FavoritosDAO nuevoFavDAO = new FavoritosDAO();
    String listarUsuarios = "listarUsuarios.jsp";
    String addUsuarios = "view/addUsuarios.jsp";
    Usuarios nuevoUsuario = new Usuarios();
    UsuariosDAO nuevoUsurioDAO = new UsuariosDAO();
    String generos = "view/generoListar.jsp";
    String album = "view/albumListar.jsp";
    String mixeshasCanciones = "view/MixeshasCanciones.jsp";
    String addMixeshasCanciones = "view/addMixeshasCanciones.jsp";
    MixeshasCanciones nuevoMixeshasCanciones = new MixeshasCanciones();
    MixeshasCancionesDAO nuevoMixeshasCancionesDAO = new MixeshasCancionesDAO();
    String listarHistorialReproduccion = "listarHistorialReproduccion.jsp";
    String historialReproduccion = "view/historialReproduccion";
    HistorialReproduccion nuevoHR = new HistorialReproduccion();
    HistorialReproduccionDAO nuevoHRDAO = new HistorialReproduccionDAO();
    String listarArtistas = "view/listarArtistas.jsp";
    Artistas nuevoArtista = new Artistas();
    ArtistasDAO nuevoArtistaDAO = new ArtistasDAO();
    String playlisthasCanciones = "view/listPlaylisthasCanciones.jsp";
    String addPlaylistCanciones = "view/addPlaylisthasCanciones.jsp";
    PlaylisthasCanciones nuevoPlaylisthasCanciones = new PlaylisthasCanciones();
    PlaylisthasCancionesDAO nuevoPlaylisthasCancionesDAO = new PlaylisthasCancionesDAO();
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");
        if(menu.equals("Principal")){
            request.getRequestDispatcher("Principal.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String acceso = "";
        String action = request.getParameter("accion");
        if (action.equalsIgnoreCase("favoritos")){
            acceso = favoritos;
        }else if(action.equalsIgnoreCase("addFavoritos")){
            acceso = addFavoritos;
        }else if (action.equalsIgnoreCase("listarUsuarios")){
            acceso = listarUsuarios;
        }else if (action.equalsIgnoreCase("addUsuarios")){
            acceso = addUsuarios;
        } else if (action.equalsIgnoreCase("listarGeneros")) {
          acceso = generos;
        }else if (action.equalsIgnoreCase("MixeshasCanciones")){
            acceso = mixeshasCanciones;
        }else if (action.equalsIgnoreCase("addMixeshasCanciones")){
            acceso = addMixeshasCanciones;
        } else if (action.equalsIgnoreCase("listarAlbum")) {
          acceso = album;
        }else if(action.equalsIgnoreCase("listarHistorialReproduccion")){
            acceso = listarHistorialReproduccion;
        }else if(action.equalsIgnoreCase("listarArtistas")){
            acceso = listarArtistas;    
        }else if (action.equalsIgnoreCase("PlaylisthasCanciones")){
            acceso = playlisthasCanciones;
        }
        RequestDispatcher vista = request.getRequestDispatcher(acceso);
        vista.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
