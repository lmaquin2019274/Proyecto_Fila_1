package interfaces;

import java.util.List;
// importar todos los model

public interface CRUD {
    
    public List listar();

//    public Nombre_modelo list(int id);
//    public boolean add(Nombre_modelo per);
//    public boolean edit(Nombre_modelo per);
//    public boolean eliminar(int id);
    
}
